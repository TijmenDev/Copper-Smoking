This Datapack is for Minecraft version 1.17

Please do not change anything in this datapack. This is a Free datapack but credits always go to the original creator: TTVgamer / TijmenDev / @ttvgamermc
In case of editing this Datapack, please credit the original creator.

ACCEPTABLE:
Made by TTVgamer / TijmenDev / @ttvgamermc, Modified by <YourNameHere>
Original by TTVgamer / TijmenDev / @ttvgamermc, Edited by <YourNameHere>
etc.

NOT ACCEPTABLE:
Made by <YourName>
Created by <YourName> and TTVgamer / TijmenDev / @ttvgamermc
etc.